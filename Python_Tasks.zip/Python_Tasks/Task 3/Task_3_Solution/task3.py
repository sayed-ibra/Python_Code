import sqlalchemy as db
import psycopg2
import pandas as pd
import numpy as np
import json
from keras.models import model_from_json

con = db.create_engine('postgresql://iti:iti@localhost/Task_3')
con.table_names()

query = """
select Pregnancies , Glucose ,
BloodPressure ,
SkinThickness ,
Insulin ,
BMI ,
DiabetesPedigreeFunction ,
Age from public."diabetes_unscored" 
Except
select Pregnancies , Glucose ,
BloodPressure ,
SkinThickness ,
Insulin ,
BMI ,
DiabetesPedigreeFunction ,
Age from public."diabetes_scored" ;
"""

diabetes = pd.read_sql(query, con)

json_file = open('/home/sayed/Desktop/Task 3/model.json', 'r')
model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(model_json)
loaded_model.load_weights("/home/sayed/Desktop/Task 3/model.h5")

array = diabetes.to_numpy()

prediction = loaded_model.predict(array)
print(prediction)

list_value=[]
for element in prediction :
        for number in element:
            if number >= .5 :
                number=1
            else :
                number=0
            list_value.append(number)

diabetes['outcome']= list_value

diabetes.to_sql(name = 'diabetes_scored',                          
                con=con,                                           
                schema = 'public',index = False ,                            
                if_exists='append')                                

