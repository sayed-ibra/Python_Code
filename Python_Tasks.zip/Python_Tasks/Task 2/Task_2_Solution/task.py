from subprocess import run, PIPE, Popen
import subprocess
import os
import argparse
import fnmatch
import json 
import pandas as pd
import numpy as np
import time



start_time = time.time()

parser = argparse.ArgumentParser()

parser.add_argument("directory", help = "Enter Directory to be listed")

parser.add_argument("-u", "--unix", action="store_true", dest="UNIX", default=False, help="This option maintain unix time")

args = parser.parse_args()


checksums = {}
duplicates = []


scanned_files = os.scandir(args.directory)
for filename in scanned_files:
            if fnmatch.fnmatch(filename, '*.json'):
                 with Popen(["md5sum", filename], stdout=PIPE) as proc:
                    checksum = proc.stdout.read().split()[0]

                    if checksum in checksums:
                        duplicates.append(filename)
                    checksums[checksum]= filename

                    if filename in duplicates :
                        print(f"this file: {filename} is duplicated")
                    else :
                
                    

                        file_1=[json.loads(line) for line in open(filename)]
                        dataset= pd.DataFrame(file_1)
                        dataset= dataset[['a','tz','r','u','t','ll','hc','cy']]
                        dataset['Web_Browser']=  dataset.a.str.extract(r'^(\w*)', expand=True)
                        dataset['Operating_System']=  dataset.a.str.extract(r'\(([^)]+)\)', expand=True)
                        dataset['Operating_System']=  dataset.Operating_System.str.extract(r'^(\w*)', expand=True)
                        dataset['From_Url']=  dataset.r.str.extract(r'([\w_-]+(?:(?:\.[\w_-]+)+))', expand=True)
                        dataset['To_Url']= dataset.u.str.extract(r'([\w_-]+(?:(?:\.[\w_-]+)+))', expand=True)
                        dataset.rename(columns = {'tz' : 'Time_Zone', 'cy': 'City','t': 'Time_In','hc':'Time_Out'}, inplace = True)
                        dataset['ll']=dataset['ll'].fillna('')
                        dataset[['longitude','latitude']] = pd.DataFrame( dataset['ll'].values.tolist(), index=dataset.index)
                        dataset.replace('', np.nan, inplace=True)
                        dataset =  dataset.dropna(axis=0)

                        if not args.UNIX:
                            creation_timestamp=[]
                            for i, row in  dataset.iterrows():
                                stamp = pd.to_datetime(row['Time_In'], unit = 's').tz_localize(row['Time_Zone']).tz_convert('UTC')
                                creation_timestamp.append(stamp)
                            dataset['Time_In'] =creation_timestamp

                        if not args.UNIX:
                            creation_timestamps=[]
                            for i, row in  dataset.iterrows():
                                stamps = pd.to_datetime(row['Time_Out'], unit = 's').tz_localize(row['Time_Zone']).tz_convert('UTC')
                                creation_timestamps.append(stamps)
                            dataset['Time_Out'] =creation_timestamps
                            dataset =  dataset[['Web_Browser','Operating_System','From_Url','To_Url','City','longitude','latitude','Time_Zone','Time_In','Time_Out']]
                            filename,file_extension = os.path.splitext(filename)
                            filename= filename+".csv"

                        file_path='/home/sayed/Desktop/ITI_Python_for_Data_Management/Task 2/target/'
                        #p = Path()
                        dataset.to_csv(filename, index=False)
                        print(f"number of transformed rows :  { len(dataset.index)}")
                        print(f"The file path : {file_path}")
print("total execution time = %s seconds " % (time.time() - start_time))
                   













